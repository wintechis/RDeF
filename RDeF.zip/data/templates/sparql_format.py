  # (r'(?i)  where|filter|group\s+by|minus|'
            #  r'distinct|reduced|from\s+named|from|order\s+by|desc|asc|limit|'
            #  r'offset|values|bindings|load|into|clear|drop|create|add|move|copy|'
            #  r'insert\s+data|delete\s+data|delete\s+where|with|delete|insert|'
            #  r'using\s+named|using|graph|default|named|all|optional|service|'
            #  r'silent|bind|undef|union|not\s+in|in|as|having|to|prefix|base)\b', Keyword),


terms = ('WHERE {', 'FILTER', 'GROUP BY', )